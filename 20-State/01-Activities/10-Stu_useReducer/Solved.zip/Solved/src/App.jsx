import { useEffect } from "react";
import CarProvider from "./utils/CarContext";
import Garage from "./components/Garage";
import "./App.css";

function App() {
  const title = "Activity 10: useReducer";
  useEffect(() => {
    document.title = title;
  }, []);

  return (
    <div className="app">
      <h1>22.1 State</h1>
      <h4 style={{ color: "lightseagreen" }}>{title}</h4>
      {/* Provider wraps all the logic that handles/updates our state */}
      <CarProvider>
        <Garage />
      </CarProvider>
    </div>
  );
}

export default App;
