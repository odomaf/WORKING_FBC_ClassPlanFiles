import { useReducer, useState } from "react";
import reducer from "../utils/reducer";

// Starting data for the garage inventory
const initialState = {
  cars: [
    { id: 1, make: "Honda", model: "Civic", year: "2008" },
    { id: 2, make: "Tesla", model: "Model Y", year: "2021" },
  ],
};

export default function Garage() {
  // useReducer gives us the current state and a dispatch function
  const [state, dispatch] = useReducer(reducer, initialState);

  // useState is still useful for local form inputs
  const [form, setForm] = useState({
    make: "",
    model: "",
    year: "",
  });

  const handleChange = (event) => {
    const { name, value } = event.target;

    setForm({
      ...form,
      [name]: value,
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Prevent blank entries from being added
    if (!form.make.trim() || !form.model.trim() || !form.year.trim()) {
      return;
    }

    const newCar = {
      id: Date.now(),
      make: form.make.trim(),
      model: form.model.trim(),
      year: form.year.trim(),
    };

    // Dispatch an action to the reducer
    dispatch({
      type: "ADD_CAR",
      payload: newCar,
    });

    // Clear the form after adding a new car
    setForm({
      make: "",
      model: "",
      year: "",
    });
  };

  const removeCar = (id) => {
    dispatch({
      type: "REMOVE_CAR",
      payload: id,
    });
  };

  return (
    <section className="dashboard-card">
      <form className="car-form" onSubmit={handleSubmit}>
        <input
          name="make"
          placeholder="Make"
          value={form.make}
          onChange={handleChange}
        />

        <input
          name="model"
          placeholder="Model"
          value={form.model}
          onChange={handleChange}
        />

        <input
          name="year"
          placeholder="Year"
          value={form.year}
          onChange={handleChange}
        />

        <button type="submit" className="btn-add">
          Add Car
        </button>
      </form>

      {state.cars.length ? (
        <div className="car-list">
          {state.cars.map((car) => (
            <div className="car-card" key={car.id}>
              <div className="car-details">
                <h3>
                  {car.year} {car.make} {car.model}
                </h3>
                <p>Inventory ID: {car.id}</p>
              </div>

              <button
                type="button"
                className="btn-remove"
                onClick={() => removeCar(car.id)}>
                Remove
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p className="empty-state">No cars in the garage yet.</p>
      )}
    </section>
  );
}
